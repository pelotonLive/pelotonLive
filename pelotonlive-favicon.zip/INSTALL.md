# PelotonLive Favicon — Installation

## Files included

| File | Purpose |
|---|---|
| `favicon.svg` | Main favicon — used by modern browsers, scales perfectly |
| `favicon.ico` | Fallback for older browsers (contains 16×16, 32×32, 48×48) |
| `favicon-16x16.png` | Explicit 16px PNG |
| `favicon-32x32.png` | Explicit 32px PNG |
| `favicon-180x180.png` | Apple touch icon (home screen on iPhone/iPad) |
| `favicon-192x192.png` | Android home screen / PWA |
| `favicon-512x512.png` | PWA splash screen |

## How to install

1. Copy all files into the **root** of your `pelotonlive` repository (same folder as `index.html`)

2. Add these lines inside the `<head>` of `index.html`, just before the closing `</head>` tag:

```html
<!-- Favicon -->
<link rel="icon" type="image/svg+xml" href="favicon.svg">
<link rel="icon" type="image/x-icon" href="favicon.ico">
<link rel="apple-touch-icon" sizes="180x180" href="favicon-180x180.png">
<link rel="icon" type="image/png" sizes="32x32" href="favicon-32x32.png">
<link rel="icon" type="image/png" sizes="16x16" href="favicon-16x16.png">
```

3. Commit and push — Netlify will redeploy and the favicon will appear in the browser tab.

## Browser support

- **Chrome, Firefox, Edge, Safari (modern)** — use `favicon.svg` directly
- **Safari (older) / iOS** — use `favicon-180x180.png` via `apple-touch-icon`
- **IE / very old browsers** — fall back to `favicon.ico`
